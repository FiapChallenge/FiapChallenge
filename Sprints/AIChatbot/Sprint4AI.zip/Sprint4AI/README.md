Integrantes - RM :

- Augusto Barcelos Barros - 98078
- Gabriel Gribl de Carvalho - 96270
- Gabriel Souza de Queiroz - 98570
- Gabriela Zanotto Alves Rodrigues - 551629

Fonte:
Tipos de guinchos - https://cadeguincho.com/blog/quais-sao-os-tipos-de-guinchos-disponiveis-no-mercado/
Tipos de veículos pesados - https://www.luiztools.com.br/post/base-de-dados-com-todas-as-marcas-e-modelos-de-veiculos/
Tipos de situações onde se pode pedir um guincho para veículos pesados - https://spaceautomotive.com.br/tudo-o-que-voce-precisa-saber-sobre-reboque-de-veiculos/

Foi usado também o próprio site da porto seguro para entender como funciona o sistema deles e que tipo de situação eles atendem
https://www.portoseguro.com.br/consulta-de-clientes/localizar-o-guincho

Explicação dos dados
Os dados serão usados para facilitar o entendimento da IA sobre qual guincho o usuário precisa. Com base nas informações da tabela onde o próprio usuário fornecerá o sistema irá reconhecer o tipo de veículo que deve ser usado para a situação, ele precisa da informação NOME, MARCA, SITUAÇÃO.
